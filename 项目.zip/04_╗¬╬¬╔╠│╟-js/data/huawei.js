let product_list = [
    {
        "id": 1,
        "url": "https://res4.vmallres.com/pimages/FssCdnProxy/vmall_product_uom/pmsSalesFile/800_800_8D12649BC2A317FD6805B4012B95FD79.png",
        "title": "Mate 70 Pro",
        "des": "鸿蒙AI|红枫原色影像|超可靠玄武架构",
        "cart_num": 0,
        "price": 6999,
        "is_select": false
    },
    {
        "id": 2,
        "url": "https://res8.vmallres.com/pimages/uomcdn/CN/pms/202406/gbom/6942103128202/800_800_BDCDFF9AB892DABC4E97D0323D4C8753mp.png",
        "title": "Pura 70 北斗卫星消息版",
        "des": "超高速风驰闪拍|第二代昆仑玻璃",
        "cart_num": 0,
        "price": 5599,
        "is_select": false
    },
    {
        "id": 3,
        "url": "https://res3.vmallres.com/pimages/uomcdn/CN/pms/202309/gbom/6942103107221/800_800_959526DD397D0C873FCE80CE67C9A0BFmp.png",
        "title": "Mate X5",
        "des": "超轻薄四曲折叠|超高清高分辨率临境双屏",
        "cart_num": 0,
        "price": 10499,
        "is_select": false
    },
    {
        "id": 4,
        "url": "https://res3.vmallres.com/pimages/FssCdnProxy/vmall_product_uom/pmsSalesFile/800_800_E9CA35FB3EFDE5304007D6A90ABF065E.png",
        "title": "华为畅享 70X",
        "des": "一键北斗 鸿蒙安全|华为巨鲸长续航",
        "cart_num": 0,
        "price": 1999,
        "is_select": false
    },
    {
        "id": 5,
        "url": "https://res7.vmallres.com/pimages/uomcdn/CN/pms/202403/gbom/6942103107719/800_800_5818B6A12914274ED24FB8FE47F1CD34mp.png",
        "title": "Mate 60",
        "des": "超可靠玄武架构|全焦段超清影像",
        "cart_num": 0,
        "price": 5499,
        "is_select": false
    },
    {
        "id": 6,
        "url": "https://res3.vmallres.com/pimages/uomcdn/CN/pms/202409/gbom/6942103136221/800_800_333848611DC0B1FC64909F87CD048F2Cmp.png",
        "title": "Mate XT 非凡大师",
        "des": "10.2英寸超形态三折叠大屏",
        "cart_num": 0,
        "price": 23999,
        "is_select": false
    },
    {
        "id": 7,
        "url": "https://res5.vmallres.com/pimages/uomcdn/CN/pms/202404/gbom/6942103121074/800_800_FDDA6BC9766655586FD6EB3E003F316Dmp.png",
        "title": "Pura 70 Ultra",
        "des": "超聚光伸缩摄像头|超高速风驰闪拍",
        "cart_num": 0,
        "price": 7999,
        "is_select": false
    },
    {
        "id": 8,
        "url": "https://res8.vmallres.com/pimages/uomcdn/CN/pms/202410/gbom/6942103137129/800_800_CC8A9746DF24D6EA90EF9322630569DCmp.png",
        "title": "nova 13 Pro",
        "des": "前后多焦段人像|IAI修图",
        "cart_num": 0,
        "price": 3849,
        "is_select": false
    }
]